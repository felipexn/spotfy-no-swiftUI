//
//  hackatruck7App.swift
//  hackatruck7
//
//  Created by Turma01-23 on 23/01/24.
//

import SwiftUI

@main
struct hackatruck7App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
